class Booking < ActiveRecord::Base
end
