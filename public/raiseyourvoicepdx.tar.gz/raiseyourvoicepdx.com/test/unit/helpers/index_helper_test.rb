require 'test_helper'

class IndexHelperTest < ActionView::TestCase
end
