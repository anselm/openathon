require 'test_helper'

class NotesHelperTest < ActionView::TestCase
end
