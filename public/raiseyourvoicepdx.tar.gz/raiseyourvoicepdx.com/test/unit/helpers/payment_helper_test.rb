require 'test_helper'

class PaymentHelperTest < ActionView::TestCase
end
